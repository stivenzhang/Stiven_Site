create definer = root@localhost view `vedi merda` as
select `gestione_persone`.`persone`.`nome`          AS `nome`,
       `gestione_persone`.`persone`.`cognome`       AS `cognome`,
       `gestione_persone`.`data`.`date`             AS `date`,
       `gestione_persone`.`data_persona`.`presenza` AS `presenza`
from ((`gestione_persone`.`data` join `gestione_persone`.`data_persona`
       on (`gestione_persone`.`data_persona`.`id_data` like
           `gestione_persone`.`data`.`id`)) join `gestione_persone`.`persone`
      on (`gestione_persone`.`data_persona`.`id_persona` like `gestione_persone`.`persone`.`id`));

